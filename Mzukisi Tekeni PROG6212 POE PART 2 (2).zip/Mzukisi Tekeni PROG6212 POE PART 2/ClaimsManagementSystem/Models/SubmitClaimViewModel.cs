﻿using System.ComponentModel.DataAnnotations;

namespace ClaimsManagementSystem.Models
{
    public class SubmitClaimViewModel
    {
        [Required]
        public double HoursWorked { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }

        public string Notes { get; set; }

        public List<IFormFile> Documents { get; set; }
    }
}
