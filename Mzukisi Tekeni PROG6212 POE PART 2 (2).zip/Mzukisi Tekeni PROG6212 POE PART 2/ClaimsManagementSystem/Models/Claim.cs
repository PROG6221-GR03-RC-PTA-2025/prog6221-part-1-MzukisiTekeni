﻿namespace ClaimsManagementSystem.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public string ClaimId { get; set; }
        public int UserId { get; set; }
        public string LecturerName { get; set; }
        public DateTime Date { get; set; }
        public string Status { get; set; } // Pending, Approved, Rejected, Paid
        public decimal Amount { get; set; }
        public double HoursWorked { get; set; }
        public decimal HourlyRate { get; set; }
        public string Notes { get; set; }
        public List<ClaimDocument> Documents { get; set; } = new List<ClaimDocument>();
    }
}
