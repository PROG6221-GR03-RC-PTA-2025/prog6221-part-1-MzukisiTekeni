﻿using ClaimsManagementSystem.Models;

namespace ClaimsManagementSystem.Data
{
    public class SeedData
    {
        public static void Initialize(ApplicationDbContext context)
        {
            if (context.Users.Any())
                return; // Database already seeded

            // Add users
            var users = new[]
            {
                new User
                {
                    Id = 1,
                    Username = "mzukisi",
                    Password = "password123",
                    FullName = "Mzukisi Tekeni",
                    JobTitle = "Lecturer",
                    Role = "Lecturer",
                    ProfileImage = "/images/profile1.jpg"
                },
                new User
                {
                    Id = 2,
                    Username = "lwako",
                    Password = "password123",
                    FullName = "Lwako Tekeni",
                    JobTitle = "Academic Manager",
                    Role = "Manager",
                    ProfileImage = "/images/profile2.jpg"
                }
            };
            context.Users.AddRange(users);

            // Add claims
            var claims = new[]
            {
                new Claim { ClaimId = "#100", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 1, 2), Status = "Paid", Amount = 5200, HoursWorked = 40, HourlyRate = 130, Notes = "January teaching hours" },
                new Claim { ClaimId = "#101", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 2, 1), Status = "Pending", Amount = 6000, HoursWorked = 50, HourlyRate = 120, Notes = "February teaching hours" },
                new Claim { ClaimId = "#103", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 3, 7), Status = "Rejected", Amount = 500, HoursWorked = 5, HourlyRate = 100, Notes = "Workshop session" },
                new Claim { ClaimId = "#104", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 4, 16), Status = "Pending", Amount = 6000, HoursWorked = 48, HourlyRate = 125, Notes = "April lectures" },
                new Claim { ClaimId = "#105", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 5, 25), Status = "Approved", Amount = 6000, HoursWorked = 45, HourlyRate = 133.33m, Notes = "May teaching" },
                new Claim { ClaimId = "#106", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 6, 1), Status = "Rejected", Amount = 800, HoursWorked = 8, HourlyRate = 100, Notes = "Extra session" },
                new Claim { ClaimId = "#107", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 7, 1), Status = "Approved", Amount = 10000, HoursWorked = 80, HourlyRate = 125, Notes = "July teaching" },
                new Claim { ClaimId = "#108", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 8, 1), Status = "Approved", Amount = 100, HoursWorked = 1, HourlyRate = 100, Notes = "Guest lecture" },
                new Claim { ClaimId = "#109", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 9, 13), Status = "Pending", Amount = 70000, HoursWorked = 560, HourlyRate = 125, Notes = "Full semester" },
                new Claim { ClaimId = "#110", UserId = 1, LecturerName = "Mzukisi Tekeni", Date = new DateTime(2025, 10, 3), Status = "Approved", Amount = 9000, HoursWorked = 72, HourlyRate = 125, Notes = "October teaching" }
            };
            context.Claims.AddRange(claims);

            // Add notifications
            var notifications = new[]
            {
                new Notification { UserId = 1, Message = "Your Claim #100 has been successfully paid", CreatedDate = DateTime.Now.AddDays(-5), IsRead = false },
                new Notification { UserId = 1, Message = "Your Claim #101 is missing some documents", CreatedDate = DateTime.Now.AddDays(-3), IsRead = false },
                new Notification { UserId = 1, Message = "Your Claim #106 has been rejected", CreatedDate = DateTime.Now.AddDays(-2), IsRead = false },
                new Notification { UserId = 1, Message = "Your Claim #105 has been approved", CreatedDate = DateTime.Now.AddDays(-1), IsRead = false },
                new Notification { UserId = 2, Message = "Your Claim #100 has been successfully paid", CreatedDate = DateTime.Now.AddDays(-5), IsRead = false },
                new Notification { UserId = 2, Message = "Your Claim #101 is missing some documents", CreatedDate = DateTime.Now.AddDays(-3), IsRead = false },
                new Notification { UserId = 2, Message = "Your Claim #106 has been rejected", CreatedDate = DateTime.Now.AddDays(-2), IsRead = false },
                new Notification { UserId = 2, Message = "Your Claim #105 has been approved", CreatedDate = DateTime.Now.AddDays(-1), IsRead = false }
            };
            context.Notifications.AddRange(notifications);

            context.SaveChanges();
        }
    }
}
