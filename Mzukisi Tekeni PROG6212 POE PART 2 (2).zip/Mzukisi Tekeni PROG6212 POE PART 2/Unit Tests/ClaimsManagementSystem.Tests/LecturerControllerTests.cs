﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Xunit;
using ClaimsManagementSystem.Controllers;
using ClaimsManagementSystem.Data;
using ClaimsManagementSystem.Models;
using Microsoft.AspNetCore.Hosting;
using Moq;

namespace ClaimsManagementSystem.Tests
{
    public class LecturerControllerTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly LecturerController _controller;

        public LecturerControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            _context = new ApplicationDbContext(options);

            // Seed test data - ALL fields must be non-null
            _context.Users.Add(new User
            {
                Id = 1,
                Username = "testlecturer",
                Password = "password",
                FullName = "Test Lecturer",
                JobTitle = "Lecturer",
                Role = "Lecturer",
                ProfileImage = ""
            });

            _context.Claims.AddRange(new[]
            {
                new ClaimsManagementSystem.Models.Claim
                {
                    Id = 1,
                    ClaimId = "#100",
                    UserId = 1,
                    LecturerName = "Test Lecturer",
                    Date = DateTime.Now,
                    Status = "Pending",
                    Amount = 5000,
                    HoursWorked = 40,
                    HourlyRate = 125,
                    Notes = "Test notes",
                    Documents = new List<ClaimDocument>()
                },
                new ClaimsManagementSystem.Models.Claim
                {
                    Id = 2,
                    ClaimId = "#101",
                    UserId = 1,
                    LecturerName = "Test Lecturer",
                    Date = DateTime.Now.AddDays(-5),
                    Status = "Approved",
                    Amount = 6000,
                    HoursWorked = 48,
                    HourlyRate = 125,
                    Notes = "Test notes",
                    Documents = new List<ClaimDocument>()
                }
            });

            _context.SaveChanges();

            // Setup controller
            var mockEnvironment = new Mock<IWebHostEnvironment>();
            mockEnvironment.Setup(m => m.WebRootPath).Returns(Path.GetTempPath());

            _controller = new LecturerController(_context, mockEnvironment.Object);

            // Mock user authentication
            var user = new ClaimsPrincipal(new ClaimsIdentity(new[]
            {
                new System.Security.Claims.Claim(ClaimTypes.NameIdentifier, "1"),
                new System.Security.Claims.Claim(ClaimTypes.Name, "testlecturer"),
                new System.Security.Claims.Claim(ClaimTypes.Role, "Lecturer")
            }, "mock"));

            // Mock TempData (THIS IS THE FIX!)
            var httpContext = new DefaultHttpContext();
            var tempData = new TempDataDictionary(httpContext, Mock.Of<ITempDataProvider>());

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = httpContext
            };
            _controller.ControllerContext.HttpContext.User = user;
            _controller.TempData = tempData;
        }

        [Fact]
        public async Task Dashboard_ReturnsViewResult()
        {
            // Act
            var result = await _controller.Dashboard();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public async Task Dashboard_ReturnsCorrectModel()
        {
            // Act
            var result = await _controller.Dashboard();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<DashboardViewModel>(viewResult.Model);
            Assert.NotNull(model);
        }

        [Fact]
        public async Task Dashboard_ReturnsCorrectUser()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as DashboardViewModel;

            // Assert
            Assert.NotNull(model?.CurrentUser);
            Assert.Equal("Test Lecturer", model.CurrentUser.FullName);
        }

        [Fact]
        public async Task Dashboard_ReturnsCorrectClaimCount()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as DashboardViewModel;

            // Assert
            Assert.NotNull(model?.Claims);
            Assert.Equal(2, model.Claims.Count);
        }

        [Fact]
        public async Task Dashboard_CalculatesPendingCountCorrectly()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as DashboardViewModel;

            // Assert
            Assert.Equal(1, model?.PendingCount);
        }

        [Fact]
        public async Task Dashboard_CalculatesApprovedCountCorrectly()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as DashboardViewModel;

            // Assert
            Assert.Equal(1, model?.ApprovedCount);
        }

        [Fact]
        public void GetClaimDetails_ReturnsJsonResult()
        {
            // Act
            var result = _controller.GetClaimDetails(1);

            // Assert
            Assert.IsType<JsonResult>(result);
        }

        [Fact]
        public void GetClaimDetails_ReturnsNotFoundForInvalidId()
        {
            // Act
            var result = _controller.GetClaimDetails(999);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        [Fact]
        public async Task SubmitClaim_WithValidModel_RedirectsToDashboard()
        {
            // Arrange
            var model = new SubmitClaimViewModel
            {
                HoursWorked = 50,
                HourlyRate = 130,
                Notes = "Test claim"
            };

            // Act
            var result = await _controller.SubmitClaim(model);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Dashboard", redirectResult.ActionName);
        }

        [Fact]
        public async Task SubmitClaim_CreatesNewClaimInDatabase()
        {
            // Arrange
            var initialCount = _context.Claims.Count();
            var model = new SubmitClaimViewModel
            {
                HoursWorked = 40,
                HourlyRate = 150,
                Notes = "Test"
            };

            // Act
            await _controller.SubmitClaim(model);

            // Assert
            Assert.Equal(initialCount + 1, _context.Claims.Count());
        }

        [Fact]
        public async Task SubmitClaim_CalculatesAmountCorrectly()
        {
            // Arrange
            var model = new SubmitClaimViewModel
            {
                HoursWorked = 40,
                HourlyRate = 150,
                Notes = "Test"
            };

            // Act
            await _controller.SubmitClaim(model);

            // Assert
            var newClaim = _context.Claims.OrderByDescending(c => c.Id).FirstOrDefault();
            Assert.NotNull(newClaim);
            Assert.Equal(6000, newClaim.Amount);
        }

        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}