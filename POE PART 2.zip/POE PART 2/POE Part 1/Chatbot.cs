﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace POE_Part_1
{
    internal class Chatbot
    {
        public string Name { get; set; }
        public Dictionary<string,string> ChatbotResponses;
        public ArrayList PhishingTipsArray;
        Random Myrand;
        public ArrayList HistoryArray;
        public string LastTopic;
        public ArrayList PasswordSafetyTipsArray;
        public ArrayList SafeBrowsingTipsArray;
        public ArrayList MemoryRecall;
        public Chatbot(string Name)
        {

            this.Name = Name;
            ChatbotResponses = new Dictionary<string, string>{
                {"purpose","My purpose is to spread cybersecurity awarennes" },
                {"thanks" ,"You're welcome! have a great day"},
                {"password safety",
                    "Password Safety refers to the precautions taken to keep passwords and the systems they safeguard safe from compromise or unwanted access\n\nWould you like to know more details about Password Safety?\n" },
                {"phishing",
                    "Phishing is the type of cyberattack where malicious individuals impersonate trustworthy entities to deceive people into revealing sensitive information\n\nWould you like to know more details about Phishing?\n"},
                {"safe browsing","safe Browsing refers to practices and technologies designed to protect internet users from malicious websites.\n\nWould you like to know more details about Safe Browsing?\n" }
            };
            PhishingTipsArray = new ArrayList() {"Here are some Phishing Tips: ","Check the sender","Think before you click","look for red flags" };
            Myrand = new Random();
            HistoryArray = new ArrayList();
            LastTopic = "";
            PasswordSafetyTipsArray = new ArrayList() { "Here are some Password Safety Tips: ","Use Strong, unique passwords", "Enable two-factor authentication", "Avoid saving passwords in your browser" };
            SafeBrowsingTipsArray = new ArrayList() { "Here are some Safe Browsing Tips:", "Use HTTPS websites", "Avoid suspicious pop-ups", "Keep your browser updated" };
            MemoryRecall = new ArrayList();
        }
        public string Respond(string UserMessage, User newUser)
       {
            if (string.IsNullOrWhiteSpace(UserMessage))
                return "I didn't catch that. could you repeat?";

            UserMessage = UserMessage.ToLower();

            if (UserMessage.Contains("hello"))
            {
                return "Hello! " + newUser.Name + " How can i assist you today?";
            }
           
            else if (UserMessage.Contains("how are you"))
            {
                return "I'm just a bot " + newUser.Name + ", but i'm doing great! what about you?";
            }
            else if(UserMessage.Contains("fine")|| UserMessage.Contains("good")|| UserMessage.Contains("okay"))
            {
                return "That's good, How can i assist you today? ";
            }
            else if(UserMessage.Contains("phishing") && UserMessage.Contains("tip"))
            {
                int Pos = Myrand.Next(0,PhishingTipsArray.Count);
                return (string)PhishingTipsArray[Pos];
            }
            else if(UserMessage.Contains("worried")|| UserMessage.Contains("frustrated")|| UserMessage.Contains("curious")
                && UserMessage.Contains("phishing"))
            {

                return "It's completetly Understandable to feel that way. Phishing can be very convincing. let me share some tips to help you stay safe";
            }
            else if (UserMessage.Contains("worried") || UserMessage.Contains("frustrated") || UserMessage.Contains("curious")
               && UserMessage.Contains("password safety"))
            {

                return "It's completetly Understandable to feel that way. Password Safety can be a concern. let me share some tips to help you stay safe";
            }
            else if (UserMessage.Contains("worried") || UserMessage.Contains("frustrated") || UserMessage.Contains("curious")
               && UserMessage.Contains("safe browsing"))
            {

                return "It's completetly Understandable to feel that way. Safe Browsing is very important nowadays. let me share some tips to help you stay safe";
            }
            else if(UserMessage.Contains("confused"))
            {
                return "Would you like to know more details about "+LastTopic+"?";
            }
            else if (UserMessage.Contains("yes"))
            {
                string MoreTips = "";
                if(LastTopic.Equals("phishing"))
                {
                    for (int i = 0; i < PhishingTipsArray.Count; i++)
                    {
                        MoreTips += "\n" + PhishingTipsArray[i];
                    }
                }
               else if(LastTopic.Equals("password safety"))
               {
                    for (int i = 0; i < PasswordSafetyTipsArray.Count; i++)
                    {
                        MoreTips += "\n" + PasswordSafetyTipsArray[i];
                    }
               }
                else if (LastTopic.Equals("safe browsing"))
                {
                    for (int i = 0; i < SafeBrowsingTipsArray.Count; i++)
                    {
                        MoreTips += "\n" + SafeBrowsingTipsArray[i];
                    }
                }
                return MoreTips;
            }
            else if(UserMessage.Contains("no"))
            {
                return "As someone interested in " + LastTopic + " you might also want to review other cyber security topics like Password safety, Phishing, and Safe Browsing.";
            }
            else if (UserMessage.Contains("interested"))
            {
               
                foreach (string item in ChatbotResponses.Keys)
                {
                    if (UserMessage.Contains(item))
                    {
                        LastTopic = item;
                    }
                }

                if (LastTopic.Equals("phishing"))
                {
                    MemoryRecall.Add(LastTopic);
                    return "Great i'll remember that you're interested in " + LastTopic + " it is important to know about it in order to protect yourself from attacks";
                }
                if(LastTopic.Equals("safe browsing"))
                {
                    MemoryRecall.Add(LastTopic);
                    return "Great i'll remember that you're interested in " + LastTopic + " it is important to know about it in order to protect yourself online";
                }
                if(LastTopic.Equals("password safety"))
                {
                    MemoryRecall.Add(LastTopic);
                    return "Great i'll remember that you're interested in " + LastTopic + " it is important to know about it in order to protect yourself";
                }
                return "I can only cover these Cybersecurity topics [Phishing,Password Safety, and Safe Browsing]";

            }
            else if (UserMessage.Contains("exit"))
            {
                string Memory = "";
                if (MemoryRecall.Count != 0)
                {
                    for (int i = 0; i < MemoryRecall.Count; i++)
                    {
                        string Cur = (string)MemoryRecall[i];
                        if(Cur.Equals("phishing"))
                        {
                            Memory += "As someone interested in Phishing, you might want to explore how to recognize suspicious emails and avoid clicking unkown links\n";
                        }
                        else if(Cur.Equals("password safety"))
                        {
                            Memory += "As someone interested in password safety, you might want to look into using a password manager and enabling two-factor authentication\n";
                        }
                        else if(Cur.Equals("safe browsing"))
                        {
                            Memory += "As someone interested in safe browsing, you might want to reconsider using secure connectionsand avoid suspicious websites\n";
                        }
                                         
                    }
                }
                
                return Memory +"\nexit";
            }
            else
            {
                foreach (string item in ChatbotResponses.Keys)
                {
                    if (UserMessage.Contains(item)) 
                    {
                        LastTopic = item;
                        return ChatbotResponses[item];
                    } 
                   
                }
                return "i don't think i understand, could you please paraphrase?";
            }
       }
      
    }
}
