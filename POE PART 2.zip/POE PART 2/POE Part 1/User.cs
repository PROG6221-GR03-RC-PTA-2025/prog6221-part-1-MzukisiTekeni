﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POE_Part_1
{
    internal class User
    {
        public string Name { get; set; }

        public User(string Name)
        {
            this.Name = Name;
        }
    }
}
