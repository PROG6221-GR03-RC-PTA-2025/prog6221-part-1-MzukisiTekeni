﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using ClaimsManagementSystem.Data;
using ClaimsManagementSystem.Models;

namespace ClaimsManagementSystem.Controllers
{
    [Authorize(Roles = "Manager")]
    public class ManagementController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ManagementController(ApplicationDbContext context)
        {
            _context = context;
        }

        private int GetCurrentUserId()
        {
            return int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
        }

        public async Task<IActionResult> Dashboard(string status = "Pending")
        {
            var userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);
            var allClaims = await _context.Claims
                .Include(c => c.Documents)
                .OrderByDescending(c => c.Date)
                .ToListAsync();

            var filteredClaims = string.IsNullOrEmpty(status) || status == "All"
                ? allClaims
                : allClaims.Where(c => c.Status == status).ToList();

            var notifications = await _context.Notifications
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.CreatedDate)
                .Take(10)
                .ToListAsync();

            var viewModel = new ManagementDashboardViewModel
            {
                CurrentUser = user,
                TotalClaims = allClaims.Count,
                PaidCount = allClaims.Count(c => c.Status == "Paid"),
                PendingCount = allClaims.Count(c => c.Status == "Pending"),
                ApprovedCount = allClaims.Count(c => c.Status == "Approved"),
                RejectedCount = allClaims.Count(c => c.Status == "Rejected"),
                TotalClaimValue = allClaims.Sum(c => c.Amount),
                PendingClaimValue = allClaims.Where(c => c.Status == "Pending").Sum(c => c.Amount),
                ApprovedClaimValue = allClaims.Where(c => c.Status == "Approved").Sum(c => c.Amount),
                RejectedClaimValue = allClaims.Where(c => c.Status == "Rejected").Sum(c => c.Amount),
                PaidClaimValue = allClaims.Where(c => c.Status == "Paid").Sum(c => c.Amount),
                Claims = filteredClaims,
                Notifications = notifications,
                SelectedStatus = status
            };

            return View(viewModel);
        }

        [HttpGet]
        public IActionResult GetClaimDetails(int id)
        {
            var claim = _context.Claims
                .Include(c => c.Documents)
                .FirstOrDefault(c => c.Id == id);

            if (claim == null)
                return NotFound();

            return Json(new
            {
                claimId = claim.ClaimId,
                lecturerName = claim.LecturerName,
                date = claim.Date.ToString("dd MMMM yyyy"),
                status = claim.Status,
                amount = claim.Amount.ToString("C"),
                hoursWorked = claim.HoursWorked,
                hourlyRate = claim.HourlyRate.ToString("C"),
                notes = claim.Notes ?? "No additional notes",
                documents = claim.Documents.Select(d => new
                {
                    id = d.Id,
                    fileName = d.FileName,
                    fileSize = FormatFileSize(d.FileSize),
                    uploadedDate = d.UploadedDate.ToString("dd MMM yyyy")
                })
            });
        }

        [HttpPost]
        public async Task<IActionResult> ApproveClaim([FromBody] ClaimActionRequest request)
        {
            var claim = await _context.Claims.FindAsync(request.Id);
            if (claim == null)
                return Json(new { success = false, message = "Claim not found" });

            claim.Status = "Approved";
            await _context.SaveChangesAsync();

            // Create notification for lecturer
            var notification = new Notification
            {
                UserId = claim.UserId,
                Message = $"Your Claim {claim.ClaimId} has been approved",
                CreatedDate = DateTime.Now,
                IsRead = false
            };
            _context.Notifications.Add(notification);
            await _context.SaveChangesAsync();

            return Json(new { success = true, message = "Claim approved successfully" });
        }

        [HttpPost]
        public async Task<IActionResult> RejectClaim([FromBody] RejectClaimRequest request)
        {
            var claim = await _context.Claims.FindAsync(request.Id);
            if (claim == null)
                return Json(new { success = false, message = "Claim not found" });

            claim.Status = "Rejected";
            claim.Notes = (claim.Notes ?? "") + $"\nRejection Reason: {request.Reason}";
            await _context.SaveChangesAsync();

            // Create notification for lecturer
            var notification = new Notification
            {
                UserId = claim.UserId,
                Message = $"Your Claim {claim.ClaimId} has been rejected",
                CreatedDate = DateTime.Now,
                IsRead = false
            };
            _context.Notifications.Add(notification);
            await _context.SaveChangesAsync();

            return Json(new { success = true, message = "Claim rejected successfully" });
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }
    }

    public class ClaimActionRequest
    {
        public int Id { get; set; }
    }

    public class RejectClaimRequest
    {
        public int Id { get; set; }
        public string Reason { get; set; }
    }
}

