﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using ClaimsManagementSystem.Data;
using ClaimsManagementSystem.Models;

namespace ClaimsManagementSystem.Controllers
{
    [Authorize(Roles = "Lecturer")]
    public class LecturerController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public LecturerController(ApplicationDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        private int GetCurrentUserId()
        {
            return int.Parse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value);
        }

        public async Task<IActionResult> Dashboard()
        {
            var userId = GetCurrentUserId();
            var user = await _context.Users.FindAsync(userId);
            var claims = await _context.Claims
                .Where(c => c.UserId == userId)
                .Include(c => c.Documents)
                .OrderByDescending(c => c.Date)
                .ToListAsync();

            var notifications = await _context.Notifications
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.CreatedDate)
                .Take(10)
                .ToListAsync();

            var viewModel = new DashboardViewModel
            {
                CurrentUser = user,
                PaidCount = claims.Count(c => c.Status == "Paid"),
                PendingCount = claims.Count(c => c.Status == "Pending"),
                ApprovedCount = claims.Count(c => c.Status == "Approved"),
                RejectedCount = claims.Count(c => c.Status == "Rejected"),
                Claims = claims,
                Notifications = notifications
            };

            return View(viewModel);
        }

        [HttpGet]
        public IActionResult GetClaimDetails(int id)
        {
            var claim = _context.Claims
                .Include(c => c.Documents)
                .FirstOrDefault(c => c.Id == id);

            if (claim == null)
                return NotFound();

            return Json(new
            {
                claimId = claim.ClaimId,
                lecturerName = claim.LecturerName,
                date = claim.Date.ToString("dd MMMM yyyy"),
                status = claim.Status,
                amount = claim.Amount.ToString("C"),
                hoursWorked = claim.HoursWorked,
                hourlyRate = claim.HourlyRate.ToString("C"),
                notes = claim.Notes ?? "No additional notes",
                documents = claim.Documents.Select(d => new
                {
                    id = d.Id,
                    fileName = d.FileName,
                    fileSize = FormatFileSize(d.FileSize),
                    uploadedDate = d.UploadedDate.ToString("dd MMM yyyy")
                })
            });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SubmitClaim(SubmitClaimViewModel model)
        {
            if (ModelState.IsValid)
            {
                var userId = GetCurrentUserId();
                var user = await _context.Users.FindAsync(userId);

                var claim = new Models.Claim
                {
                    ClaimId = $"#{await GetNextClaimNumber()}",
                    UserId = userId,
                    LecturerName = user.FullName,
                    Date = DateTime.Now,
                    Status = "Pending",
                    HoursWorked = model.HoursWorked,
                    HourlyRate = model.HourlyRate,
                    Amount = (decimal)model.HoursWorked * model.HourlyRate,
                    Notes = model.Notes
                };

                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                // Handle file uploads
                if (model.Documents != null && model.Documents.Any())
                {
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", claim.ClaimId);
                    Directory.CreateDirectory(uploadsFolder);

                    foreach (var file in model.Documents)
                    {
                        if (file.Length > 0)
                        {
                            var fileName = Path.GetFileName(file.FileName);
                            var filePath = Path.Combine(uploadsFolder, fileName);

                            using (var stream = new FileStream(filePath, FileMode.Create))
                            {
                                await file.CopyToAsync(stream);
                            }

                            var document = new ClaimDocument
                            {
                                ClaimId = claim.Id,
                                FileName = fileName,
                                FilePath = filePath,
                                FileSize = file.Length,
                                UploadedDate = DateTime.Now
                            };

                            _context.ClaimDocuments.Add(document);
                        }
                    }

                    await _context.SaveChangesAsync();
                }

                TempData["Success"] = "Claim submitted successfully!";
                return RedirectToAction("Dashboard");
            }

            return RedirectToAction("Dashboard");
        }

        [HttpPost]
        public async Task<IActionResult> UploadDocuments(int claimId, List<IFormFile> documents)
        {
            var claim = await _context.Claims.FindAsync(claimId);
            if (claim == null || claim.UserId != GetCurrentUserId())
                return Json(new { success = false, message = "Claim not found" });

            if (documents != null && documents.Any())
            {
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads", claim.ClaimId);
                Directory.CreateDirectory(uploadsFolder);

                foreach (var file in documents)
                {
                    if (file.Length > 0 && file.Length <= 5 * 1024 * 1024) // 5MB limit
                    {
                        var allowedExtensions = new[] { ".pdf", ".docx", ".doc", ".xlsx" };
                        var extension = Path.GetExtension(file.FileName).ToLower();

                        if (!allowedExtensions.Contains(extension))
                            continue;

                        var fileName = Path.GetFileName(file.FileName);
                        var filePath = Path.Combine(uploadsFolder, fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            await file.CopyToAsync(stream);
                        }

                        var document = new ClaimDocument
                        {
                            ClaimId = claim.Id,
                            FileName = fileName,
                            FilePath = filePath,
                            FileSize = file.Length,
                            UploadedDate = DateTime.Now
                        };

                        _context.ClaimDocuments.Add(document);
                    }
                }

                await _context.SaveChangesAsync();

                // Create notification
                var notification = new Notification
                {
                    UserId = claim.UserId,
                    Message = $"Documents uploaded for Claim {claim.ClaimId}",
                    CreatedDate = DateTime.Now,
                    IsRead = false
                };
                _context.Notifications.Add(notification);
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Documents uploaded successfully" });
            }

            return Json(new { success = false, message = "No valid documents provided" });
        }

        private async Task<int> GetNextClaimNumber()
        {
            var lastClaim = await _context.Claims
                .OrderByDescending(c => c.Id)
                .FirstOrDefaultAsync();

            if (lastClaim == null)
                return 100;

            var lastNumber = int.Parse(lastClaim.ClaimId.Replace("#", ""));
            return lastNumber + 1;
        }

        private string FormatFileSize(long bytes)
        {
            string[] sizes = { "B", "KB", "MB", "GB" };
            double len = bytes;
            int order = 0;
            while (len >= 1024 && order < sizes.Length - 1)
            {
                order++;
                len = len / 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }
    }
}

