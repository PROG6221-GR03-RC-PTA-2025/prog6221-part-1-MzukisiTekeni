﻿namespace ClaimsManagementSystem.Models
{
    public class DashboardViewModel
    {
        public User CurrentUser { get; set; }
        public int PaidCount { get; set; }
        public int PendingCount { get; set; }
        public int ApprovedCount { get; set; }
        public int RejectedCount { get; set; }
        public List<Claim> Claims { get; set; }
        public List<Notification> Notifications { get; set; }
    }
}
