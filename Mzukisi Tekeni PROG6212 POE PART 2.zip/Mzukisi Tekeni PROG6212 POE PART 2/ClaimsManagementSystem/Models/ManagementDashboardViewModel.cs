﻿namespace ClaimsManagementSystem.Models
{
    public class ManagementDashboardViewModel
    {
        public User CurrentUser { get; set; }
        public int TotalClaims { get; set; }
        public int PaidCount { get; set; }
        public int PendingCount { get; set; }
        public int ApprovedCount { get; set; }
        public int RejectedCount { get; set; }
        public decimal TotalClaimValue { get; set; }
        public decimal PendingClaimValue { get; set; }
        public decimal ApprovedClaimValue { get; set; }
        public decimal RejectedClaimValue { get; set; }
        public decimal PaidClaimValue { get; set; }
        public List<Claim> Claims { get; set; }
        public List<Notification> Notifications { get; set; }
        public string SelectedStatus { get; set; } = "Pending";
    }
}
