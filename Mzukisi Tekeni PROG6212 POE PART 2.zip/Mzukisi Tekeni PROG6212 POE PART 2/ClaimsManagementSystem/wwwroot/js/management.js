﻿// Management Dashboard JavaScript Functions

// View claim details in modal
function viewClaimDetails(claimId) {
    const modal = new bootstrap.Modal(document.getElementById('viewClaimModal'));
    modal.show();

    fetch(`/Management/GetClaimDetails?id=${claimId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('claimDetailsContent').innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Claim ID:</strong> ${data.claimId}</p>
                        <p><strong>Lecturer:</strong> ${data.lecturerName}</p>
                        <p><strong>Date:</strong> ${data.date}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-${data.status.toLowerCase()}">${data.status}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Hours Worked:</strong> ${data.hoursWorked}</p>
                        <p><strong>Hourly Rate:</strong> ${data.hourlyRate}</p>
                        <p><strong>Total Amount:</strong> <strong>${data.amount}</strong></p>
                    </div>
                </div>
                <hr>
                <h6>Notes:</h6>
                <p>${data.notes}</p>
                <hr>
                <h6>Documents:</h6>
                ${data.documents.length > 0 ?
                    `<ul class="list-group">
                        ${data.documents.map(doc => `
                            <li class="list-group-item">
                                <i class="fas fa-file me-2"></i> ${doc.fileName} 
                                <small class="text-muted">(${doc.fileSize})</small>
                                <br><small class="text-muted">Uploaded: ${doc.uploadedDate}</small>
                            </li>
                        `).join('')}
                    </ul>` :
                    '<p class="text-muted">No documents uploaded</p>'}
            `;
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('claimDetailsContent').innerHTML = `
                <div class="alert alert-danger">
                    Failed to load claim details. Please try again.
                </div>
            `;
        });
}

// Approve a claim
function approveClaim(claimId) {
    if (!confirm('Are you sure you want to approve this claim?')) {
        return;
    }

    fetch('/Management/ApproveClaim', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: claimId })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert(data.message, 'success');
                setTimeout(() => {
                    location.reload();
                }, 1500);
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Failed to approve claim. Please try again.', 'danger');
        });
}

// Reject a claim with reason
function rejectClaim(claimId) {
    document.getElementById('rejectClaimId').value = claimId;
    const modal = new bootstrap.Modal(document.getElementById('rejectModal'));
    modal.show();
}

// Submit rejection
function submitRejection() {
    const claimId = document.getElementById('rejectClaimId').value;
    const reason = document.getElementById('rejectionReason').value;

    if (!reason || reason.trim() === '') {
        showAlert('Please provide a reason for rejection', 'warning');
        return;
    }

    fetch('/Management/RejectClaim', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            id: parseInt(claimId),
            reason: reason
        })
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert(data.message, 'success');
                setTimeout(() => {
                    location.reload();
                }, 1500);
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Failed to reject claim. Please try again.', 'danger');
        });
}

// Filter claims by status
function filterClaims(status) {
    window.location.href = `/Management/Dashboard?status=${status}`;
}

// Show notifications (scroll to panel)
function showNotifications() {
    const notificationsPanel = document.querySelector('.notifications-panel');
    if (notificationsPanel) {
        notificationsPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        notificationsPanel.style.border = '2px solid #3498db';
        setTimeout(() => {
            notificationsPanel.style.border = 'none';
        }, 2000);
    }
}

// Helper function to show alerts
function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = '9999';
    alertDiv.style.minWidth = '300px';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}