﻿// Lecturer Dashboard JavaScript Functions

// View claim details in modal
function viewClaimDetails(claimId) {
    const modal = new bootstrap.Modal(document.getElementById('viewClaimModal'));
    modal.show();

    fetch(`/Lecturer/GetClaimDetails?id=${claimId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('claimDetailsContent').innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Claim ID:</strong> ${data.claimId}</p>
                        <p><strong>Lecturer:</strong> ${data.lecturerName}</p>
                        <p><strong>Date:</strong> ${data.date}</p>
                        <p><strong>Status:</strong> <span class="status-badge status-${data.status.toLowerCase()}">${data.status}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Hours Worked:</strong> ${data.hoursWorked}</p>
                        <p><strong>Hourly Rate:</strong> ${data.hourlyRate}</p>
                        <p><strong>Total Amount:</strong> <strong>${data.amount}</strong></p>
                    </div>
                </div>
                <hr>
                <h6>Notes:</h6>
                <p>${data.notes}</p>
                <hr>
                <h6>Documents:</h6>
                ${data.documents.length > 0 ?
                    `<ul class="list-group">
                        ${data.documents.map(doc => `
                            <li class="list-group-item">
                                <i class="fas fa-file me-2"></i> ${doc.fileName} 
                                <small class="text-muted">(${doc.fileSize})</small>
                                <br><small class="text-muted">Uploaded: ${doc.uploadedDate}</small>
                            </li>
                        `).join('')}
                    </ul>` :
                    '<p class="text-muted">No documents uploaded</p>'}
            `;
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('claimDetailsContent').innerHTML = `
                <div class="alert alert-danger">
                    Failed to load claim details. Please try again.
                </div>
            `;
        });
}

// Open upload modal with pre-selected claim
function uploadDocuments(claimId) {
    document.getElementById('claimSelect').value = claimId;
    const modal = new bootstrap.Modal(document.getElementById('uploadModal'));
    modal.show();
}

// Submit document upload
function submitUpload() {
    const claimId = document.getElementById('claimSelect').value;
    const files = document.getElementById('uploadFiles').files;

    if (!claimId || files.length === 0) {
        showAlert('Please select a claim and at least one file', 'warning');
        return;
    }

    // Validate file sizes and types
    const maxSize = 5 * 1024 * 1024; // 5MB
    const allowedTypes = ['.pdf', '.docx', '.doc', '.xlsx'];

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const extension = '.' + file.name.split('.').pop().toLowerCase();

        if (file.size > maxSize) {
            showAlert(`File ${file.name} is too large. Maximum size is 5MB.`, 'danger');
            return;
        }

        if (!allowedTypes.includes(extension)) {
            showAlert(`File ${file.name} has invalid type. Only PDF, DOCX, DOC, and XLSX are allowed.`, 'danger');
            return;
        }
    }

    const formData = new FormData();
    formData.append('claimId', claimId);
    for (let i = 0; i < files.length; i++) {
        formData.append('documents', files[i]);
    }

    fetch('/Lecturer/UploadDocuments', {
        method: 'POST',
        body: formData
    })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showAlert(data.message, 'success');
                setTimeout(() => {
                    location.reload();
                }, 1500);
            } else {
                showAlert(data.message, 'danger');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert('Upload failed. Please try again.', 'danger');
        });
}

// Show notifications (scroll to panel)
function showNotifications() {
    const notificationsPanel = document.querySelector('.notifications-panel');
    if (notificationsPanel) {
        notificationsPanel.scrollIntoView({ behavior: 'smooth', block: 'start' });
        notificationsPanel.style.border = '2px solid #3498db';
        setTimeout(() => {
            notificationsPanel.style.border = 'none';
        }, 2000);
    }
}

// Helper function to show alerts
function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show position-fixed top-0 start-50 translate-middle-x mt-3`;
    alertDiv.style.zIndex = '9999';
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    document.body.appendChild(alertDiv);

    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
}

// Calculate total amount in real-time
document.addEventListener('DOMContentLoaded', function () {
    const hoursInput = document.getElementById('hoursWorked');
    const rateInput = document.getElementById('hourlyRate');

    if (hoursInput && rateInput) {
        const calculateTotal = () => {
            const hours = parseFloat(hoursInput.value) || 0;
            const rate = parseFloat(rateInput.value) || 0;
            const total = hours * rate;

            const totalDisplay = document.getElementById('totalAmount');
            if (totalDisplay) {
                totalDisplay.textContent = `R ${total.toFixed(2)}`;
            }
        };

        hoursInput.addEventListener('input', calculateTotal);
        rateInput.addEventListener('input', calculateTotal);
    }
});