﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
using ClaimsManagementSystem.Controllers;
using ClaimsManagementSystem.Data;
using ClaimsManagementSystem.Models;

namespace ClaimsManagementSystem.Tests
{
    public class ManagementControllerTests : IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly ManagementController _controller;

        public ManagementControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            _context = new ApplicationDbContext(options);

            // Seed test data
            _context.Users.Add(new User
            {
                Id = 2,
                Username = "testmanager",
                Password = "password",
                FullName = "Test Manager",
                JobTitle = "Manager",
                Role = "Manager",
                ProfileImage = "" // Add this
            });

            _context.Claims.AddRange(new[]
            {
                new ClaimsManagementSystem.Models.Claim
                {
                    Id = 1,
                    ClaimId = "#100",
                    UserId = 1,
                    LecturerName = "Test Lecturer",
                    Date = DateTime.Now,
                    Status = "Pending",
                    Amount = 5000,
                    HoursWorked = 40,
                    HourlyRate = 125,
                    Notes = "Test",
                    Documents = new List<ClaimDocument>()
                },
                new ClaimsManagementSystem.Models.Claim
                {
                    Id = 2,
                    ClaimId = "#101",
                    UserId = 1,
                    LecturerName = "Test Lecturer",
                    Date = DateTime.Now.AddDays(-5),
                    Status = "Approved",
                    Amount = 6000,
                    HoursWorked = 48,
                    HourlyRate = 125,
                    Notes = "Test",
                    Documents = new List<ClaimDocument>()
                },
                new ClaimsManagementSystem.Models.Claim
                {
                    Id = 3,
                    ClaimId = "#102",
                    UserId = 1,
                    LecturerName = "Test Lecturer",
                    Date = DateTime.Now.AddDays(-10),
                    Status = "Rejected",
                    Amount = 1000,
                    HoursWorked = 8,
                    HourlyRate = 125,
                    Notes = "Test",
                    Documents = new List<ClaimDocument>()
                }
            });

            _context.SaveChanges();

            _controller = new ManagementController(_context);

            // Mock user authentication
            var user = new ClaimsPrincipal(new ClaimsIdentity(new[]
            {
                new System.Security.Claims.Claim(ClaimTypes.NameIdentifier, "2"),
                new System.Security.Claims.Claim(ClaimTypes.Name, "testmanager"),
                new System.Security.Claims.Claim(ClaimTypes.Role, "Manager")
            }, "mock"));

            _controller.ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = user }
            };
        }

        [Fact]
        public async Task Dashboard_ReturnsViewResult()
        {
            // Act
            var result = await _controller.Dashboard();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public async Task Dashboard_ReturnsCorrectTotalClaimCount()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as ManagementDashboardViewModel;

            // Assert
            Assert.Equal(3, model?.TotalClaims);
        }

        [Fact]
        public async Task Dashboard_FiltersByPendingStatus()
        {
            // Act
            var result = await _controller.Dashboard("Pending");
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as ManagementDashboardViewModel;

            // Assert
            Assert.Single(model?.Claims);
            Assert.Equal("Pending", model?.Claims.First().Status);
        }

        [Fact]
        public async Task Dashboard_CalculatesPendingCountCorrectly()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as ManagementDashboardViewModel;

            // Assert
            Assert.Equal(1, model?.PendingCount);
        }

        [Fact]
        public async Task Dashboard_CalculatesApprovedCountCorrectly()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as ManagementDashboardViewModel;

            // Assert
            Assert.Equal(1, model?.ApprovedCount);
        }

        [Fact]
        public async Task Dashboard_CalculatesTotalClaimValueCorrectly()
        {
            // Act
            var result = await _controller.Dashboard();
            var viewResult = result as ViewResult;
            var model = viewResult?.Model as ManagementDashboardViewModel;

            // Assert
            Assert.Equal(12000, model?.TotalClaimValue);
        }

        [Fact]
        public async Task ApproveClaim_ChangesStatusToApproved()
        {
            // Arrange
            var request = new ClaimActionRequest { Id = 1 };

            // Act
            await _controller.ApproveClaim(request);

            // Assert
            var claim = await _context.Claims.FindAsync(1);
            Assert.Equal("Approved", claim?.Status);
        }

        [Fact]
        public async Task ApproveClaim_CreatesNotification()
        {
            // Arrange
            var request = new ClaimActionRequest { Id = 1 };
            var initialCount = _context.Notifications.Count();

            // Act
            await _controller.ApproveClaim(request);

            // Assert
            Assert.Equal(initialCount + 1, _context.Notifications.Count());
        }

        [Fact]
        public async Task RejectClaim_ChangesStatusToRejected()
        {
            // Arrange
            var request = new RejectClaimRequest
            {
                Id = 1,
                Reason = "Test reason"
            };

            // Act
            await _controller.RejectClaim(request);

            // Assert
            var claim = await _context.Claims.FindAsync(1);
            Assert.Equal("Rejected", claim?.Status);
        }

        [Fact]
        public void GetClaimDetails_ReturnsJsonResult()
        {
            // Act
            var result = _controller.GetClaimDetails(1);

            // Assert
            Assert.IsType<JsonResult>(result);
        }

        [Fact]
        public void GetClaimDetails_ReturnsNotFoundForInvalidId()
        {
            // Act
            var result = _controller.GetClaimDetails(999);

            // Assert
            Assert.IsType<NotFoundResult>(result);
        }

        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}