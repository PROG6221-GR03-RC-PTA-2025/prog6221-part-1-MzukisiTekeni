﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
using ClaimsManagementSystem.Controllers;
using ClaimsManagementSystem.Data;
using ClaimsManagementSystem.Models;

namespace ClaimsManagementSystem.Tests
{
    public class AccountControllerTests : System.IDisposable
    {
        private readonly ApplicationDbContext _context;
        private readonly AccountController _controller;

        public AccountControllerTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: System.Guid.NewGuid().ToString())
                .EnableSensitiveDataLogging()
                .Options;

            _context = new ApplicationDbContext(options);

            // Seed test user
            _context.Users.Add(new User
            {
                Id = 1,
                Username = "testuser",
                Password = "password123",
                FullName = "Test User",
                JobTitle = "Lecturer",
                Role = "Lecturer",
                ProfileImage = "" // Add this
            });

            _context.SaveChanges();

            _controller = new AccountController(_context);
        }

        [Fact]
        public void Login_Get_ReturnsViewResult()
        {
            // Act
            var result = _controller.Login();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        public void Dispose()
        {
            _context?.Dispose();
        }
    }
}